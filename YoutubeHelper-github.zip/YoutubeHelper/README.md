# YoutubeHelper

Android-приложение для улучшения работы YouTube через обход DPI. Локально запускает прокси и перенаправляет трафик через него.

## Возможности

- Автозапуск при загрузке устройства
- 4 готовых пресета (YouTube Stable, Max Speed, Stealth Mode, Custom)
- VPN и Proxy режимы работы
- Раздельное туннелирование приложений
- Живая статистика: трафик, пинг, время сессии
- Лог в реальном времени
- Импорт / экспорт настроек
- Тёмная тема (Material 3)

## Стек

- **Kotlin** + **Jetpack Compose**
- **Material 3** дизайн
- **Navigation Compose** — навигация между экранами
- **DataStore Preferences** — хранение настроек
- **Android VpnService** — туннелирование трафика
- **Coroutines / Flow** — реактивный UI

## Сборка

```bash
git clone https://github.com/you/YoutubeHelper.git
cd YoutubeHelper
./gradlew assembleDebug
```

APK будет в `app/build/outputs/apk/debug/`.

Для release-сборки с подписью:
```bash
./gradlew assembleRelease
```

## Структура проекта

```
app/src/main/java/com/youtubehelper/
├── MainActivity.kt              # Точка входа, Navigation
├── model/
│   └── Models.kt                # Данные: Preset, AppSettings, SessionStats
├── service/
│   ├── ProxyVpnService.kt       # VpnService — туннелирование
│   └── BootReceiver.kt          # Автозапуск при загрузке
├── ui/
│   ├── MainViewModel.kt         # Бизнес-логика, состояние
│   ├── components/
│   │   └── Components.kt        # Переиспользуемые компоненты
│   ├── screens/
│   │   ├── HomeScreen.kt        # Главный экран
│   │   ├── LogsScreen.kt        # Экран логов
│   │   └── SettingsScreen.kt    # Настройки
│   └── theme/
│       ├── Color.kt             # Цвета
│       └── Theme.kt             # Material 3 тема
└── utils/
    ├── LogManager.kt            # Система логирования
    └── SettingsRepository.kt    # DataStore репозиторий
```

## Интеграция с ByeDPI

Для полной работы необходимо добавить нативную библиотеку [ByeDPI](https://github.com/hufrea/byedpi):

1. Клонировать с сабмодулями:
```bash
git clone --recurse-submodules https://github.com/hufrea/byedpi
```

2. Собрать `.so` под нужные ABI (`arm64-v8a`, `x86_64`)

3. Скопировать в `app/src/main/jniLibs/`

4. Вызывать через JNI в `ProxyVpnService`

## Лицензия

GPL-3.0 · На основе [ByeByeDPI](https://github.com/romanvht/ByeByeDPI)
