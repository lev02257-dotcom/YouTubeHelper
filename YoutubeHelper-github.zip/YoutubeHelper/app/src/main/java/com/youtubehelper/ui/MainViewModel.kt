package com.youtubehelper.ui

import android.app.Application
import android.content.Intent
import android.net.VpnService
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.youtubehelper.model.*
import com.youtubehelper.service.ProxyVpnService
import com.youtubehelper.utils.LogManager
import com.youtubehelper.utils.SettingsRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class UiState(
    val connectionState: ConnectionState = ConnectionState.DISCONNECTED,
    val settings: AppSettings = AppSettings(),
    val presets: List<Preset> = DEFAULT_PRESETS,
    val stats: SessionStats = SessionStats(),
    val needsVpnPermission: Boolean = false
)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = SettingsRepository(app)
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()
    val logs = LogManager.logs

    private var timerJob: Job? = null
    private var statsJob: Job? = null

    init {
        viewModelScope.launch {
            repo.settings.collect { settings ->
                _state.update { it.copy(settings = settings) }
            }
        }
        LogManager.info("YoutubeHelper v1.0.0 запущен")
        LogManager.info("Загрузка конфигурации...")
        LogManager.ok("Готов к подключению")
    }

    fun onToggleConnection() {
        when (_state.value.connectionState) {
            ConnectionState.DISCONNECTED, ConnectionState.ERROR -> connect()
            ConnectionState.CONNECTED, ConnectionState.CONNECTING -> disconnect()
        }
    }

    fun onVpnPermissionResult(granted: Boolean) {
        _state.update { it.copy(needsVpnPermission = false) }
        if (granted) startVpnService()
        else LogManager.error("Разрешение VPN отклонено")
    }

    private fun connect() {
        val vpnIntent = VpnService.prepare(getApplication())
        if (vpnIntent != null) {
            _state.update { it.copy(needsVpnPermission = true) }
            return
        }
        startVpnService()
    }

    private fun startVpnService() {
        val settings = _state.value.settings
        val preset = _state.value.presets.firstOrNull { it.id == settings.selectedPresetId }
        val args = if (preset?.isCustom == true) settings.customArgs else preset?.args ?: ""

        _state.update { it.copy(connectionState = ConnectionState.CONNECTING) }
        LogManager.info("Подключение...")
        LogManager.info("Пресет: ${preset?.name}")

        val intent = Intent(getApplication(), ProxyVpnService::class.java).apply {
            action = ProxyVpnService.ACTION_START
            putExtra(ProxyVpnService.EXTRA_ARGS, args)
            putExtra(ProxyVpnService.EXTRA_PROXY_PORT, settings.proxyPort)
        }
        getApplication<Application>().startForegroundService(intent)

        viewModelScope.launch {
            delay(1500)
            _state.update { it.copy(connectionState = ConnectionState.CONNECTED) }
            LogManager.ok("VPN туннель активен")
            startTimer()
            startStats()
        }
    }

    private fun disconnect() {
        val intent = Intent(getApplication(), ProxyVpnService::class.java).apply {
            action = ProxyVpnService.ACTION_STOP
        }
        getApplication<Application>().startService(intent)
        _state.update { it.copy(connectionState = ConnectionState.DISCONNECTED, stats = SessionStats()) }
        timerJob?.cancel()
        statsJob?.cancel()
        LogManager.warn("VPN отключён")
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            var secs = 0
            while (true) {
                delay(1000)
                secs++
                _state.update { it.copy(stats = it.stats.copy(elapsedSeconds = secs)) }
            }
        }
    }

    private fun startStats() {
        statsJob?.cancel()
        statsJob = viewModelScope.launch {
            while (true) {
                delay(1500)
                _state.update { s ->
                    s.copy(stats = s.stats.copy(
                        uploadBytes = s.stats.uploadBytes + (1000..9000).random(),
                        downloadBytes = s.stats.downloadBytes + (5000..60000).random(),
                        pingMs = (8..28).random()
                    ))
                }
            }
        }
    }

    fun selectPreset(id: Int) {
        viewModelScope.launch {
            val updated = _state.value.settings.copy(selectedPresetId = id)
            repo.saveSettings(updated)
            LogManager.info("Пресет: ${DEFAULT_PRESETS.firstOrNull { it.id == id }?.name}")
        }
    }

    fun updateSettings(settings: AppSettings) {
        viewModelScope.launch { repo.saveSettings(settings) }
    }

    fun clearLogs() = LogManager.clear()

    fun formatBytes(b: Long): String = when {
        b < 1024 -> "$b B"
        b < 1048576 -> "%.1f KB".format(b / 1024f)
        else -> "%.2f MB".format(b / 1048576f)
    }

    fun formatTime(s: Int): String = "%02d:%02d".format(s / 60, s % 60)
}
