package com.youtubehelper.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.*
import com.youtubehelper.model.AppSettings
import com.youtubehelper.model.VpnMode
import com.youtubehelper.ui.MainViewModel
import com.youtubehelper.ui.components.*
import com.youtubehelper.ui.theme.*

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val state by vm.state.collectAsState()
    val settings = state.settings

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Surface0)
            .verticalScroll(rememberScrollState())
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Surface1)
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.Settings, contentDescription = null, tint = YouTubeRed, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Text("Настройки", style = MaterialTheme.typography.titleMedium)
        }

        HorizontalDivider(color = Surface3, thickness = 0.5.dp)

        Column(
            modifier = Modifier.padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(Modifier.height(4.dp))

            // General
            SectionLabel("Основные")
            AppCard {
                SettingRow(
                    icon = Icons.Rounded.PlayCircle,
                    iconBg = Color(0xFF2A0A0A),
                    iconTint = YouTubeRedLight,
                    title = "Автозапуск",
                    subtitle = "При загрузке устройства",
                    trailing = {
                        Switch(
                            checked = settings.autoStart,
                            onCheckedChange = { vm.updateSettings(settings.copy(autoStart = it)) },
                            colors = SwitchDefaults.colors(
                                checkedTrackColor = ColorConnected,
                                uncheckedTrackColor = Surface3,
                                uncheckedBorderColor = Surface3
                            )
                        )
                    }
                )
                HorizontalDivider(color = Surface2, thickness = 0.5.dp)
                SettingRow(
                    icon = Icons.Rounded.Tune,
                    iconBg = Color(0xFF0A1A2A),
                    iconTint = ColorInfo,
                    title = "Режим работы",
                    subtitle = if (settings.vpnMode == VpnMode.VPN) "VPN режим" else "Прокси режим",
                    trailing = {
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .border(0.5.dp, Surface3, RoundedCornerShape(8.dp))
                        ) {
                            listOf(VpnMode.VPN to "VPN", VpnMode.PROXY to "Прокси").forEach { (mode, label) ->
                                val selected = settings.vpnMode == mode
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (selected) YouTubeRed else Color.Transparent)
                                        .padding(horizontal = 10.dp, vertical = 5.dp)
                                ) {
                                    Text(label, fontSize = 12.sp, color = if (selected) Color.White else TextMuted)
                                }
                            }
                        }
                    }
                )
                HorizontalDivider(color = Surface2, thickness = 0.5.dp)
                SettingRow(
                    icon = Icons.Rounded.Apps,
                    iconBg = Color(0xFF0A2015),
                    iconTint = ColorConnected,
                    title = "Раздельное туннелирование",
                    subtitle = "${settings.splitTunnelApps.size} приложений выбрано",
                    trailing = { Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = TextHint, modifier = Modifier.size(20.dp)) }
                )
            }

            // DPI Parameters
            SectionLabel("Параметры DPI")
            AppCard {
                SettingRow(
                    icon = Icons.Rounded.Terminal,
                    iconBg = Color(0xFF1A0A2A),
                    iconTint = Color(0xFFA855F7),
                    title = "Аргументы командной строки",
                    subtitle = settings.customArgs.ifEmpty { "—" },
                    trailing = { Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = TextHint, modifier = Modifier.size(20.dp)) }
                )
                HorizontalDivider(color = Surface2, thickness = 0.5.dp)
                SettingRow(
                    icon = Icons.Rounded.Router,
                    iconBg = Color(0xFF2A1500),
                    iconTint = ColorWarning,
                    title = "Порт прокси",
                    subtitle = "${settings.proxyPort} (SOCKS5)",
                    trailing = { Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = TextHint, modifier = Modifier.size(20.dp)) }
                )
            }

            // Data
            SectionLabel("Данные")
            AppCard {
                SettingRow(
                    icon = Icons.Rounded.Upload,
                    iconBg = Color(0xFF0A1A2A),
                    iconTint = ColorInfo,
                    title = "Экспорт настроек",
                    trailing = { Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = TextHint, modifier = Modifier.size(20.dp)) }
                )
                HorizontalDivider(color = Surface2, thickness = 0.5.dp)
                SettingRow(
                    icon = Icons.Rounded.Download,
                    iconBg = Color(0xFF0A2015),
                    iconTint = ColorConnected,
                    title = "Импорт настроек",
                    trailing = { Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = TextHint, modifier = Modifier.size(20.dp)) }
                )
            }

            // About
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("YoutubeHelper v1.0.0", style = MaterialTheme.typography.bodySmall, color = TextHint)
                    Spacer(Modifier.height(2.dp))
                    Text("GPL-3.0 · На основе ByeByeDPI", style = MaterialTheme.typography.bodySmall, color = TextHint)
                }
            }

            Spacer(Modifier.height(8.dp))
        }
    }
}
