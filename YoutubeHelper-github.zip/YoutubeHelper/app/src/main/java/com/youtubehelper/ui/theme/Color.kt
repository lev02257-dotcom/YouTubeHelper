package com.youtubehelper.ui.theme

import androidx.compose.ui.graphics.Color

// YouTube Red palette
val YouTubeRed = Color(0xFFFF0000)
val YouTubeRedDark = Color(0xFFCC0000)
val YouTubeRedLight = Color(0xFFFF4444)

// Surfaces - dark theme
val Surface0 = Color(0xFF0F0F0F)
val Surface1 = Color(0xFF1A1A1A)
val Surface2 = Color(0xFF222222)
val Surface3 = Color(0xFF2A2A2A)

// Text
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFAAAAAA)
val TextMuted = Color(0xFF666666)
val TextHint = Color(0xFF444444)

// Status
val ColorConnected = Color(0xFF22C55E)
val ColorConnectedGlow = Color(0x4422C55E)
val ColorWarning = Color(0xFFF97316)
val ColorError = Color(0xFFEF4444)
val ColorInfo = Color(0xFF3B82F6)

// Badge backgrounds
val BadgeGreenBg = Color(0xFF16301E)
val BadgeBlueBg = Color(0xFF0D1F35)
val BadgeOrangeBg = Color(0xFF2A1A0D)
val BadgeGrayBg = Color(0xFF222222)
