package com.youtubehelper.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.*
import androidx.compose.ui.unit.*
import com.youtubehelper.model.*
import com.youtubehelper.ui.MainViewModel
import com.youtubehelper.ui.components.*
import com.youtubehelper.ui.theme.*

@Composable
fun HomeScreen(vm: MainViewModel) {
    val state by vm.state.collectAsState()
    val connected = state.connectionState == ConnectionState.CONNECTED
    val connecting = state.connectionState == ConnectionState.CONNECTING

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Surface0)
            .verticalScroll(rememberScrollState())
    ) {
        // Header
        HomeHeader(connected = connected, connecting = connecting, vm = vm)

        Column(
            modifier = Modifier.padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(Modifier.height(4.dp))

            // Stats row
            AnimatedVisibility(visible = connected) {
                StatsRow(stats = state.stats, vm = vm)
            }

            // Presets
            SectionLabel("Пресеты")
            PresetsCard(
                presets = state.presets,
                selectedId = state.settings.selectedPresetId,
                onSelect = vm::selectPreset
            )

            // Connect button
            ConnectButton(
                state = state.connectionState,
                onClick = vm::onToggleConnection
            )

            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun HomeHeader(connected: Boolean, connecting: Boolean, vm: MainViewModel) {
    val state by vm.state.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Surface1)
            .border(BorderStroke(0.5.dp, Surface3), RoundedCornerShape(bottomStart = 0.dp, bottomEnd = 0.dp))
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Column {
            // App title row
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Logo
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(YouTubeRed),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Rounded.PlayCircle,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("YoutubeHelper", style = MaterialTheme.typography.titleLarge)
                    Text("Обход DPI · Улучшение качества", style = MaterialTheme.typography.bodySmall)
                }
            }

            Spacer(Modifier.height(14.dp))

            // Status pill
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Surface2)
                    .border(0.5.dp, Surface3, RoundedCornerShape(12.dp))
                    .padding(horizontal = 14.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatusDot(connected = connected)
                Spacer(Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    val statusLabel = when (state.connectionState) {
                        ConnectionState.CONNECTED -> "Подключено"
                        ConnectionState.CONNECTING -> "Подключение..."
                        ConnectionState.ERROR -> "Ошибка"
                        else -> "Отключено"
                    }
                    Text(statusLabel, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                    if (connected) {
                        val preset = state.presets.firstOrNull { it.id == state.settings.selectedPresetId }
                        Text(preset?.name ?: "", style = MaterialTheme.typography.bodySmall)
                    }
                }
                Switch(
                    checked = connected || connecting,
                    onCheckedChange = { vm.onToggleConnection() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = ColorConnected,
                        uncheckedThumbColor = TextMuted,
                        uncheckedTrackColor = Surface3,
                        uncheckedBorderColor = Surface3
                    )
                )
            }
        }
    }
}

@Composable
private fun StatsRow(stats: SessionStats, vm: MainViewModel) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        StatCard(
            value = vm.formatBytes(stats.uploadBytes),
            label = "Отправлено",
            icon = Icons.Rounded.ArrowUpward,
            modifier = Modifier.weight(1f)
        )
        StatCard(
            value = vm.formatBytes(stats.downloadBytes),
            label = "Получено",
            icon = Icons.Rounded.ArrowDownward,
            modifier = Modifier.weight(1f)
        )
        StatCard(
            value = if (stats.pingMs > 0) "${stats.pingMs} мс" else "—",
            label = "Пинг",
            icon = Icons.Rounded.Speed,
            modifier = Modifier.weight(1f)
        )
        StatCard(
            value = vm.formatTime(stats.elapsedSeconds),
            label = "Время",
            icon = Icons.Rounded.Timer,
            accent = true,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun PresetsCard(presets: List<Preset>, selectedId: Int, onSelect: (Int) -> Unit) {
    AppCard {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Быстрый выбор", style = MaterialTheme.typography.titleSmall)
                Text("Нажмите для активации", style = MaterialTheme.typography.bodySmall)
            }
            PresetBadge("${presets.size} пресета", "green")
        }

        HorizontalDivider(color = Surface3, thickness = 0.5.dp)

        val badgeTypes = listOf("green", "blue", "orange", "gray")
        presets.forEachIndexed { i, preset ->
            PresetItem(
                preset = preset,
                selected = preset.id == selectedId,
                badgeType = badgeTypes.getOrElse(i) { "gray" },
                onClick = { onSelect(preset.id) }
            )
            if (i < presets.size - 1) HorizontalDivider(color = Surface2, thickness = 0.5.dp)
        }
    }
}

@Composable
private fun PresetItem(preset: Preset, selected: Boolean, badgeType: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .background(if (selected) Surface2 else Color.Transparent)
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Radio
        Box(
            modifier = Modifier
                .size(18.dp)
                .clip(CircleShape)
                .border(1.5.dp, if (selected) YouTubeRed else Surface3, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (selected) Box(
                modifier = Modifier.size(9.dp).clip(CircleShape).background(YouTubeRed)
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(preset.name, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
            if (preset.args.isNotEmpty()) MonoText(preset.args)
        }
        PresetBadge(preset.badge, badgeType)
    }
}

@Composable
private fun ConnectButton(state: ConnectionState, onClick: () -> Unit) {
    val isConnected = state == ConnectionState.CONNECTED

    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isConnected) Surface2 else YouTubeRed,
            contentColor = if (isConnected) YouTubeRedLight else Color.White
        ),
        border = if (isConnected) BorderStroke(0.5.dp, YouTubeRed.copy(alpha = 0.3f)) else null
    ) {
        when (state) {
            ConnectionState.CONNECTING -> {
                CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    strokeWidth = 2.dp,
                    color = Color.White
                )
                Spacer(Modifier.width(10.dp))
                Text("Подключение...", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }
            ConnectionState.CONNECTED -> {
                Icon(Icons.Rounded.Stop, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("Отключиться", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }
            else -> {
                Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("Подключиться", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
