package com.youtubehelper.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.youtubehelper.MainActivity
import com.youtubehelper.R
import com.youtubehelper.utils.LogManager
import kotlinx.coroutines.*
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.nio.channels.DatagramChannel

class ProxyVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.youtubehelper.START"
        const val ACTION_STOP = "com.youtubehelper.STOP"
        const val EXTRA_ARGS = "extra_args"
        const val EXTRA_PROXY_PORT = "extra_proxy_port"
        const val CHANNEL_ID = "youtubehelper_vpn"
        const val NOTIF_ID = 1001

        var isRunning = false
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return when (intent?.action) {
            ACTION_STOP -> { stopVpn(); START_NOT_STICKY }
            else -> { startVpn(intent); START_STICKY }
        }
    }

    private fun startVpn(intent: Intent?) {
        val args = intent?.getStringExtra(EXTRA_ARGS) ?: ""
        val port = intent?.getIntExtra(EXTRA_PROXY_PORT, 1080) ?: 1080

        LogManager.info("Запуск VPN сервиса...")
        LogManager.info("Аргументы: $args")

        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification("Подключение..."))

        scope.launch {
            try {
                val builder = Builder()
                    .setSession("YoutubeHelper")
                    .addAddress("10.0.0.2", 24)
                    .addDnsServer("8.8.8.8")
                    .addDnsServer("8.8.4.4")
                    .addRoute("0.0.0.0", 0)
                    .setMtu(1500)

                vpnInterface = builder.establish()
                isRunning = true

                LogManager.ok("VPN интерфейс создан успешно")
                LogManager.ok("Туннель установлен на порт $port")

                updateNotification("Подключено · YoutubeHelper")
                runTunnel(port)

            } catch (e: Exception) {
                LogManager.error("Ошибка запуска: ${e.message}")
                stopVpn()
            }
        }
    }

    private suspend fun runTunnel(proxyPort: Int) {
        val buffer = ByteBuffer.allocate(32767)
        val inputStream = FileInputStream(vpnInterface!!.fileDescriptor)
        val outputStream = FileOutputStream(vpnInterface!!.fileDescriptor)

        LogManager.info("Туннель активен, перенаправление трафика...")

        // Simplified tunnel loop — real impl uses byedpi native lib
        while (isRunning) {
            delay(100)
        }
    }

    private fun stopVpn() {
        LogManager.warn("Остановка VPN сервиса...")
        isRunning = false
        scope.coroutineContext.cancelChildren()
        vpnInterface?.close()
        vpnInterface = null
        LogManager.info("VPN сервис остановлен")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun buildNotification(text: String): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pi = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)
        val stopIntent = Intent(this, ProxyVpnService::class.java).apply { action = ACTION_STOP }
        val stopPi = PendingIntent.getService(this, 1, stopIntent, PendingIntent.FLAG_IMMUTABLE)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("YoutubeHelper")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(pi)
            .addAction(0, "Отключить", stopPi)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, buildNotification(text))
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID, "YoutubeHelper VPN", NotificationManager.IMPORTANCE_LOW
        ).apply { description = "Статус VPN подключения" }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    override fun onDestroy() {
        stopVpn()
        scope.cancel()
        super.onDestroy()
    }
}
