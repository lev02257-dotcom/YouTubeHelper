package com.youtubehelper.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.*
import com.youtubehelper.ui.MainViewModel
import com.youtubehelper.ui.theme.*
import com.youtubehelper.utils.LogEntry
import com.youtubehelper.utils.LogLevel

@Composable
fun LogsScreen(vm: MainViewModel) {
    val logs by vm.logs.collectAsState()
    val listState = rememberLazyListState()

    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) listState.animateScrollToItem(logs.size - 1)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Surface0)
    ) {
        // Toolbar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Surface1)
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Rounded.Terminal,
                contentDescription = null,
                tint = YouTubeRed,
                modifier = Modifier.size(20.dp)
            )
            Spacer(Modifier.width(10.dp))
            Text("Логи", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.weight(1f))
            Text(
                "${logs.size} записей",
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted
            )
            Spacer(Modifier.width(12.dp))
            IconButton(onClick = vm::clearLogs, modifier = Modifier.size(36.dp)) {
                Icon(Icons.Rounded.DeleteOutline, contentDescription = "Очистить", tint = TextMuted, modifier = Modifier.size(20.dp))
            }
        }

        HorizontalDivider(color = Surface3, thickness = 0.5.dp)

        if (logs.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Rounded.Terminal, contentDescription = null, tint = TextHint, modifier = Modifier.size(48.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("Логи пусты", color = TextMuted, fontSize = 15.sp)
                }
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                items(logs) { entry ->
                    LogLine(entry)
                }
            }
        }
    }
}

@Composable
private fun LogLine(entry: LogEntry) {
    val (tagColor, tag) = when (entry.level) {
        LogLevel.OK -> ColorConnected to "OK  "
        LogLevel.ERROR -> ColorError to "ERR "
        LogLevel.WARN -> ColorWarning to "WARN"
        LogLevel.INFO -> ColorInfo to "INFO"
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(Surface1)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = entry.timestamp,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = TextHint
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = tag,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = tagColor
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = entry.message,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = TextSecondary,
            modifier = Modifier.weight(1f)
        )
    }
}
