package com.youtubehelper

import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.youtubehelper.ui.MainViewModel
import com.youtubehelper.ui.screens.*
import com.youtubehelper.ui.theme.*

sealed class Screen(val route: String, val label: String, val icon: ImageVector) {
    object Home : Screen("home", "Главная", Icons.Rounded.Home)
    object Logs : Screen("logs", "Логи", Icons.Rounded.Terminal)
    object Settings : Screen("settings", "Настройки", Icons.Rounded.Settings)
}

val screens = listOf(Screen.Home, Screen.Logs, Screen.Settings)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            YoutubeHelperTheme {
                YoutubeHelperApp()
            }
        }
    }
}

@Composable
fun YoutubeHelperApp() {
    val vm: MainViewModel = viewModel()
    val state by vm.state.collectAsState()
    val navController = rememberNavController()

    val vpnLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        vm.onVpnPermissionResult(result.resultCode == android.app.Activity.RESULT_OK)
    }

    LaunchedEffect(state.needsVpnPermission) {
        if (state.needsVpnPermission) {
            val intent = VpnService.prepare(navController.context)
            if (intent != null) vpnLauncher.launch(intent)
        }
    }

    Scaffold(
        containerColor = Surface0,
        contentColor = TextPrimary,
        bottomBar = {
            BottomNavBar(navController = navController)
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            enterTransition = { fadeIn() + slideInHorizontally() },
            exitTransition = { fadeOut() + slideOutHorizontally() }
        ) {
            composable(Screen.Home.route) { HomeScreen(vm) }
            composable(Screen.Logs.route) { LogsScreen(vm) }
            composable(Screen.Settings.route) { SettingsScreen(vm) }
        }
    }
}

@Composable
fun BottomNavBar(navController: androidx.navigation.NavHostController) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    NavigationBar(
        containerColor = Surface1,
        tonalElevation = 0.dp
    ) {
        screens.forEach { screen ->
            val selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true
            NavigationBarItem(
                selected = selected,
                onClick = {
                    navController.navigate(screen.route) {
                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                icon = {
                    Icon(screen.icon, contentDescription = screen.label, modifier = Modifier.size(22.dp))
                },
                label = { Text(screen.label, style = MaterialTheme.typography.labelSmall) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = YouTubeRed,
                    selectedTextColor = YouTubeRed,
                    unselectedIconColor = TextHint,
                    unselectedTextColor = TextHint,
                    indicatorColor = Surface2
                )
            )
        }
    }
}
