package com.youtubehelper.utils

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.youtubehelper.model.AppSettings
import com.youtubehelper.model.VpnMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

object PrefsKeys {
    val AUTO_START = booleanPreferencesKey("auto_start")
    val VPN_MODE = stringPreferencesKey("vpn_mode")
    val PROXY_PORT = intPreferencesKey("proxy_port")
    val SELECTED_PRESET = intPreferencesKey("selected_preset")
    val CUSTOM_ARGS = stringPreferencesKey("custom_args")
}

class SettingsRepository(private val context: Context) {

    val settings: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            autoStart = prefs[PrefsKeys.AUTO_START] ?: false,
            vpnMode = VpnMode.valueOf(prefs[PrefsKeys.VPN_MODE] ?: VpnMode.VPN.name),
            proxyPort = prefs[PrefsKeys.PROXY_PORT] ?: 1080,
            selectedPresetId = prefs[PrefsKeys.SELECTED_PRESET] ?: 0,
            customArgs = prefs[PrefsKeys.CUSTOM_ARGS] ?: "--disorder 3 --split-pos 2"
        )
    }

    suspend fun saveSettings(settings: AppSettings) {
        context.dataStore.edit { prefs ->
            prefs[PrefsKeys.AUTO_START] = settings.autoStart
            prefs[PrefsKeys.VPN_MODE] = settings.vpnMode.name
            prefs[PrefsKeys.PROXY_PORT] = settings.proxyPort
            prefs[PrefsKeys.SELECTED_PRESET] = settings.selectedPresetId
            prefs[PrefsKeys.CUSTOM_ARGS] = settings.customArgs
        }
    }
}
