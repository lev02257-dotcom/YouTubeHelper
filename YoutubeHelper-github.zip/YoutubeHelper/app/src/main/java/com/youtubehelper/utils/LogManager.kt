package com.youtubehelper.utils

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class LogLevel { INFO, OK, WARN, ERROR }

data class LogEntry(
    val timestamp: String,
    val level: LogLevel,
    val message: String
)

object LogManager {
    private val _logs = MutableStateFlow<List<LogEntry>>(emptyList())
    val logs: StateFlow<List<LogEntry>> = _logs

    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    fun log(level: LogLevel, message: String) {
        val entry = LogEntry(
            timestamp = fmt.format(Date()),
            level = level,
            message = message
        )
        _logs.value = (_logs.value + entry).takeLast(500)
    }

    fun info(msg: String) = log(LogLevel.INFO, msg)
    fun ok(msg: String) = log(LogLevel.OK, msg)
    fun warn(msg: String) = log(LogLevel.WARN, msg)
    fun error(msg: String) = log(LogLevel.ERROR, msg)
    fun clear() { _logs.value = emptyList() }
}
