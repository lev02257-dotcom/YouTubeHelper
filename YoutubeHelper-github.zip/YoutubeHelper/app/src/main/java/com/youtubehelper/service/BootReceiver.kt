package com.youtubehelper.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.youtubehelper.utils.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        CoroutineScope(Dispatchers.IO).launch {
            val repo = SettingsRepository(context)
            val settings = repo.settings.first()
            if (settings.autoStart) {
                val preset = com.youtubehelper.model.DEFAULT_PRESETS
                    .firstOrNull { it.id == settings.selectedPresetId }
                val args = if (preset?.isCustom == true) settings.customArgs else preset?.args ?: ""

                val serviceIntent = Intent(context, ProxyVpnService::class.java).apply {
                    action = ProxyVpnService.ACTION_START
                    putExtra(ProxyVpnService.EXTRA_ARGS, args)
                    putExtra(ProxyVpnService.EXTRA_PROXY_PORT, settings.proxyPort)
                }
                context.startForegroundService(serviceIntent)
            }
        }
    }
}
