package com.youtubehelper.model

data class Preset(
    val id: Int,
    val name: String,
    val description: String,
    val args: String,
    val badge: String,
    val isCustom: Boolean = false
)

data class SessionStats(
    val uploadBytes: Long = 0L,
    val downloadBytes: Long = 0L,
    val pingMs: Int = 0,
    val elapsedSeconds: Int = 0
)

enum class VpnMode { VPN, PROXY }

enum class ConnectionState { DISCONNECTED, CONNECTING, CONNECTED, ERROR }

data class AppSettings(
    val autoStart: Boolean = false,
    val vpnMode: VpnMode = VpnMode.VPN,
    val proxyPort: Int = 1080,
    val selectedPresetId: Int = 0,
    val customArgs: String = "--disorder 3 --split-pos 2",
    val splitTunnelApps: Set<String> = emptySet()
)

val DEFAULT_PRESETS = listOf(
    Preset(0, "YouTube Stable", "Стабильный для YouTube", "--disorder 3 --split-pos 2", "Рек."),
    Preset(1, "Max Speed", "Максимальная скорость", "--fake-sni --ttl 8 --split-http", "Быстро"),
    Preset(2, "Stealth Mode", "Максимальная скрытность", "--oob --disorder 5 --fake-offset 10", "Скрытый"),
    Preset(3, "Custom", "Пользовательские параметры", "", "Свой", isCustom = true)
)
